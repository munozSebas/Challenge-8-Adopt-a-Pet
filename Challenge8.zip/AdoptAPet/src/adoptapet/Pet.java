/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adoptapet;

/**
 *
 * @author 6306841
 * Cristy Charters
 * Challenge 8
 * Due April 19 2022
 */

/*
This class is made to recieve a toString and print the date we recieved in AdoptAPet.
And with its implemented Comparable we can compare date of birth

Constructors, setters and getters, are made.


*/
public class Pet implements Comparable<Pet> {
    private String petName;
    private String petSpecies;
    private int dateOfBirth;
    private long mcNum;

    public Pet(String petName, int dateOfBirth, String petSpecies, long mcNum) {
        this.petName = petName;
        this.dateOfBirth = dateOfBirth;
        this.petSpecies = petSpecies;
        this.mcNum = mcNum;
    }

    /*
    Setters and getters
    Return: petName, dateOfBirth, petSpecies, mcNum.
    */
    public String getpetName() {
        return petName;
    }

    public void setpetName(String petName) {
        this.petName = petName;
    }

    public int getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(int dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getPetSpecies() {
        return petSpecies;
    }

    public void setPetSpecies(String petSpecies) {
        this.petSpecies = petSpecies;
    }

    public long getMcNum() {
        return mcNum;
    }

    public void setMcNum(long mcNum) {
        this.mcNum = mcNum;
    }

    @Override
    public String toString() {
        return "\nThe pet name is:" + petName + "\nTheir date of birth: " + dateOfBirth + "\nThe species it is: " + petSpecies + "\nIts microchip number: " + mcNum ;
    }
    
    /*
    The compareTo method allows us to compare the dateOfBirth and the way it is
    Returned: 1, 0, -1 it is done so its in ascending order
    */
    public int compareTo(Pet otherPet)
    {
        if (this.dateOfBirth > otherPet.dateOfBirth)
        {
            return 1;
        }
        else if (this.dateOfBirth == otherPet.dateOfBirth)
        {
            return 0;
        }
        else
        {
            return -1;
        }
    }

    /*
    The equals method is used so that we can cast obj into Pet object. 
    It is done before comparing petName, dateOfBirth, Species and mcNum.
    
    Return: True if they match False if they dont.
    */
public boolean equals (Object anObj)
{
    if (anObj instanceof Pet)
    {

    Pet other = (Pet)anObj;
    if (other.getpetName().equalsIgnoreCase(this.petName))
    {
                other.getPetSpecies().equalsIgnoreCase(this.petSpecies);
                
                other.getDateOfBirth();
                other.getMcNum();
              
    }
      return true;
    }
    else

    
    return false;
  }
}
