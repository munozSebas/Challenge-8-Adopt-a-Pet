/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adoptapet;

/**
 *
 * @author sebas
 */
public class Menu {
    
    
    public static void main (String[] args)
    {
        Challenge8GUI menu = new Challenge8GUI();
        menu.setVisible(true);
    }
}
