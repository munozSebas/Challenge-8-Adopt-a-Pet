/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adoptapet;


import java.util.Collections;
import java.util.EmptyStackException;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;
/**
 *
 * @author 6306841
 * Title: Challenge 8
 * Professor: Charters
 * Due April 19 2022
 * 
 */

/*
This class i meant to use linked list such as Stacks Queues and Priority Queue
And display to the user the Menu and what they wish to pick
*/
public class AdoptAPet {

    /**
     * @param args the command line arguments
     */
    public static Stack<Long> microchips = new Stack<Long>();
    public static Queue<Pet> cats = new LinkedList<Pet>();
    public static Queue<Pet> dogs = new LinkedList<Pet>();
    public static PriorityQueue<Pet> animalShelter = new PriorityQueue<Pet>();
    
    // 
   
    /*
    This is the driver class where I used a switch case method to allow the user to pick what 
    menu option they want.
    And a try catch was also stated in case user enters a String
    
    */
    public static void main(String[] args) {
        //0.  Instantiate AdoptAPet and call the object shelter.
        
        AdoptAPet adoptAPet = new AdoptAPet();

        Scanner keyboard = new Scanner (System.in);
        displayMenu();
        //
        int option = 0;
        
            
            do {
                try {
            option = keyboard.nextInt();
            switch (option){
            case 0: pushMicroChip();
            break;
            case 1: donateCat();
            break;
            case 2: donateDog();
            break;
            case 3: adoptCat();
            break;
            case 4: adoptDog();
            break;
            case 5: adoptOldestPet();
            break;
            case 6: showPets();
            break;
            case 7: displayMenu();
            break;
         
            default: displayMenu();

                        }  
            if (option > 7)
            {
                System.out.println("Please enter a number from 0 to 7");
            }
        
            }
                catch (InputMismatchException e)
            {
                
                 System.out.println("Please enter a numerical value from 0 - 7");
                 keyboard.next();
                 
                         
            }
            

            
            } while (option !=7);
                System.out.println("Thank you for visiting the Animal Sheler. Please support us and come again.");
        
        
            }

            
     /*
    This method is where I display the actual menu, to that it can be freely used throughout the program
    A try catch is also stated so only numerical values are allowd.
    
    */
    public static void displayMenu()
    {
         System.out.println("Welcome to Sebastians Pets site\n ");
         System.out.println("We give you the option to Adopt, Donate and Put a Micro chip into your pet"
                 + "\nWhat would you like to do ?");
        
         try {
             System.out.println("\n0.Add New Microchip \n1.Donate a cat \n2.Donate a dog \n3.Adopt a cat \n4.Adopt a dog \n5.Adopt Oldest Pet \n6.Show Pets \n7.Exit");
         }
         catch (InputMismatchException e){
             System.out.println("Please enter a numeric value of 0 - 7");
         }
         
    }
    
         /*
    This method is option 1, so the user is allows to donate a cat as long as they input the name of the cat and its Date of birth
    A try catch is also used so that only numerical values are inserted. With this A do while is used for each insertion so they are asked until
    the right input is inserted. And a try catch is used so we do not get an error if the stack is empty. 
    
    A conversion was done (valueOf) so we can transform the three ints into a String then combine those Strings into dateOfBirth 
    
    Then the values are then transferred to the cats queue, the user is then re-directed to the MENU
    */  
    public static void donateCat()
    {
        //1. define variables for name, species, dateOfBirth, microChipNumber
        
        String name;
        String species = "cat";
        int month;
        int day;
        int year;
        int dateOfBirth;
        
        long mcNum = 0;
        
        
      try {  //2. Ask user to give you all values except microchip
        Scanner keyboard = new Scanner (System.in);
        
        System.out.println("To donate a cat enter: ");
        System.out.println("Their name: ");
        name = keyboard.nextLine();
      
        
        
      do {  
        System.out.println("Their date of birth: ");
          System.out.println("Year (YYYY): ");
          year = keyboard.nextInt();
          
       if (year >=2022 || year <= 2000)
             
          {
              System.out.println("Please enter a valid year");
              //keyboard.next();
          }
      } while (year >=2022 || year <= 2000);
      
      
      do {
          System.out.println("Month(M or MM): ");
          month = keyboard.nextInt();
          
          if (month >12 || month < 1)
          {
              System.out.println("Please enter valid month");
          }
                     
      } while (month >12 || month < 1);
      
      do {
          System.out.println("Day(D or DD): ");
          day = keyboard.nextInt();
          if (day >31 || day < 1)
          {
              System.out.println("Please enter valid day");
          }
          
      }while (day >31 || day <1);
      
          String yearC = String.valueOf(year);
          String monthC = String.valueOf(month);
          String dayC = String.valueOf(day);
          
          String combine = yearC + monthC + dayC;
          
          dateOfBirth = Integer.valueOf(combine);
          System.out.println(dateOfBirth);
          

        //3. call the popMicroChip() method to obtain microchip #
        mcNum = popMicroChip();
         
        displayMenu();
        System.out.println("\nYour cat was added to our data system");
             System.out.println("You may select another option now");

        //4. create a Pet object with all the data
        Pet petCat = new Pet(name, dateOfBirth, species, mcNum);
        
        //5. put the Pet object into the cat queue
        cats.add(petCat);
        
        //6. put the Pet object into the priority queue called animalShelter
        animalShelter.add(petCat);

    }
      catch (EmptyStackException e)
      {
      }
    }
    
    /*
    
    */
    
    /*
    This is option 2. Same code from donateCat is being used here. We are allows the user to donate a dog under the exception that they
    fill out the required criterias. But this time the information is sent to the dogs Queue.
    
    */
    public static void donateDog()
    {
        //1. define variables for name, species, dateOfBirth, microChipNumber
        String name;
        String species = "dog";
        int dateOfBirth;
        int year;
        int month;
        int day;
        long mcNum = 0;
        
        try {
        //2. Ask user to give you all values except microchip
        Scanner keyboard = new Scanner (System.in);
        
        System.out.println("To donate a dog enter: ");
        System.out.println("Their name: ");
        name = keyboard.nextLine();
        

        do {  
        System.out.println("Their date of birth: ");
          System.out.println("Year (YYYY): ");
          year = keyboard.nextInt();
          
       if (year >=2022 || year <= 2000)
             
          {
              System.out.println("Please enter a valid year");
              //keyboard.next();
          }
      } while (year >=2022 || year <= 2000);
      
      
      do {
          System.out.println("Month (M or MM): ");
          month = keyboard.nextInt();
          
          if (month >12 || month < 1)
          {
              System.out.println("Please enter valid month");
          }
                     
      } while (month >12 || month < 1);
      
      do {
          System.out.println("Day (D or DD): ");
          day = keyboard.nextInt();
          if (day >31 || day < 1)
          {
              System.out.println("Please enter valid day");
          }
          
      }while (day >31 || day <1);
      
          String yearC = String.valueOf(year);
          String monthC = String.valueOf(month);
          String dayC = String.valueOf(day);
          
          String combine = yearC + monthC + dayC;
          
          dateOfBirth = Integer.valueOf(combine);
          System.out.println(dateOfBirth);

         mcNum = popMicroChip();
         displayMenu();
         System.out.println("\nYour dog was added to our data system");
            System.out.println("You may select another option now");

        Pet pet = new Pet (name ,dateOfBirth ,species, mcNum);
 
        dogs.add(pet);
  
        animalShelter.add(pet);
        }
        catch (EmptyStackException e)
      {
      }
        
    }

    
    /*
    This method is option 3, if the user selects this option. They are allowed to adopt the cat that is next in Queue.
    When the cat is adopted they are removed from the Queue. However With the if statement and isEmpty method. 
    If the queue is empty they are not allowed to donate and are redirected to the main menu.
    */
 
    public static void adoptCat()
    {
        Scanner keyboard = new Scanner(System.in);
        String catInput;
        
     
       if (cats.isEmpty()) {   
            displayMenu();
             System.out.println("No cats available to adopt at the moment ");
        }
    
         else {
         try {
           Pet cat =cats.remove();
           animalShelter.remove();
           System.out.println("The cats information that you are going to adopt is: " + cat);
             System.out.println("To return to the menu enter BACK");
             catInput = keyboard.nextLine();
             if (catInput.equalsIgnoreCase("BACK"));
         {
             displayMenu();
         }
             
             
       } catch (NoSuchElementException e)
       {
       }
     
       }
    }
    
    
    /*
    As option 4 this method is same as adoptCat difference here is that we are adopting a Dog. And after the dog in queue is adopted 
    it is then removed from the Queue. And if there are no dogs to adopt, then "No dogs available to adopt at the moment"
    This is used with if else statemnets and after the option is done then the user must enter BACK to return back to the menu.
    */
    public static void adoptDog()
    {
        Scanner keyboard = new Scanner (System.in);
        String dogInput;
      try {
        if (dogs.isEmpty()) {
            displayMenu();
            System.out.println("No dogs available to adopt at the moment ");
        }
       else {
           Pet dog =dogs.remove();
           animalShelter.remove();
          
           System.out.println("The dogs information that you are going to adopt is: " + dog);
           
            System.out.println("To return to menu enter BACK");
           dogInput = keyboard.nextLine();
            if (dogInput.equalsIgnoreCase("BACK"));
         {
             displayMenu();
         }
       }
       }
      catch (NoSuchElementException e)
      {
          
      }
    }
    
    
/*
    As option 5 the user is allowed to adopt the oldest pet. As the other adopt methods if there are no pets to adopts "No pets available to 
    adopt at the moment". However to adopt the oldest pet, the compareTo method in the other class Pet is used so we can obtain the oldest pet.
    
    */    
    public static void adoptOldestPet()
    {
        
      Scanner keyboard = new Scanner (System.in);
        String backInput;
        String dogCatInput;
        

      try {
        if (animalShelter.isEmpty()) {
            displayMenu();
            System.out.println("No pets available to adopt at the moment ");
        }
        
        
      else{
            System.out.println("Which old pet would you like to adopt ?");
            System.out.println("Dog or Cat");
            
            dogCatInput = keyboard.nextLine();
             if (dogCatInput.equalsIgnoreCase("Dog"))
             {
                 Pet dog =dogs.remove();
                 animalShelter.remove();
                 System.out.println("The oldest Dog you are going to adopt is" + dog);
             }
             
             if (dogCatInput.equalsIgnoreCase("Cat"))
             {
                 Pet cat =cats.remove();
                 animalShelter.remove();
                 System.out.println("The oldest Cat you are going to adopt is" + cat);
             }
            
      
           System.out.println("To return to menu enter BACK");
           backInput = keyboard.nextLine();
            if (backInput.equalsIgnoreCase("BACK"));
         {
             displayMenu();
         }
       }
       }
      catch (NoSuchElementException e)
      {
          
      }
    }
      
     /*
    Option 6: this allows the user to see which pets are in the shelter. Cats, dogs and oldest pet are shown by using Iterators ro display them in
    their respective slot. After the user is shown the menu, they must enter BACK to return to the menu.
    */
    public static void showPets()
    {
        Scanner keyboard = new Scanner (System.in);
        String showInput;
        System.out.println("The pets we have at the shelter: ");
        System.out.println("\n*****Cats*****:");

            Iterator <Pet> catQueue = cats.iterator();
            while (catQueue.hasNext())
            {
                System.out.println(catQueue.next());
            }
            
           
        System.out.println("\n*****Dogs*****:");  

            Iterator <Pet> dogQueue = dogs.iterator();
            while (dogQueue.hasNext())
            {
                System.out.println(dogQueue.next());
            }

         System.out.println("\n*****Our oldest pets*****: ");   
          Iterator <Pet> PQ = animalShelter.iterator();
            while (PQ.hasNext())
            {
                System.out.println(PQ.next());
            }
            
        System.out.println("To go back to menu enter BACK");
        showInput = keyboard.nextLine();
        if (showInput.equalsIgnoreCase("BACK"));
         {
             displayMenu();
         }
    }
    
    /*
    as Option 0, in order to donate a cat or dog. It needs a microchip. So if the user is trying to donate a cat dog
    They will be redirected here first if they have no chips. 
    */
    public static void pushMicroChip()
    {
        if ( microchips.empty())
        {
            
            
             for (int i =0; i <= 100; i++)
             {
                microchips.push(System.nanoTime());
             
             }
             displayMenu();
             System.out.println("100 microchips are going to be added now");
        }
        else {
        
        Scanner keyboard = new Scanner (System.in);
       String mcInput;
        System.out.println("\nTo add 100 more microchips"); 
        System.out.println("Enter YES to add microchips");
        System.out.println("To go back to the menu enter BACK");
        mcInput = keyboard.nextLine();
        
         if (mcInput.equalsIgnoreCase("BACK"));
         {
             displayMenu();
         }
        
        if (!microchips.empty())
        {
            System.out.println("There are microchips in the system");
            System.out.println("To go back to the menu: \nEnter BACK");
            mcInput.equalsIgnoreCase("BACK");
 
        }
        
        
        if (mcInput.equalsIgnoreCase("YES")) {
            for (int i =0; i <= 100; i++)
         {
        microchips.push(System.nanoTime());
             
            }
            System.out.println("\n100 microchips were added");
            System.out.println("You may select another option now");
           
        }
           
        }
    }
    
    /*
    This method is done when a user is trying to donate a cat with no microchip
    The system tells the user "There are no microchip at the moment"
    so here they are requested to go back to the menu, it then 
    
    Returns: the microchip from the stack
    */
    public static Long popMicroChip()
    {
        if (microchips.empty())
        {
            System.out.println("There are no micrchip at the moment");
            System.out.println("Enter 0 to generate 100 microchips");
        }
        else
        {

           microchips.pop();
        }
        return microchips.pop();
    }
    
    
    
    
}
